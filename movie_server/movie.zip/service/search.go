package service

import "github.com/gin-gonic/gin"

func Search(c *gin.Context) {

}
